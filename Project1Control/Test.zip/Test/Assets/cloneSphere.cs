﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cloneSphere : MonoBehaviour {


    public GameObject clone;
    public float initialDelay = 0;
    public float repeatRate = 1f;
    int numberClone = 0;
    public float randDist = 2f;
	// Use this for initialization
	void Start () {

		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
